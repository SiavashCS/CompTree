function [ NN, triplets] = RCTFindNNDistM( RCT, q, l)

%RCTFINDNN Summary of this function goes here
%   Detailed explanation goes here
w = RCT.w;
h = RCT.height;
V = RCT.Levels;
L = RCT.Levels;
P = RCT.Parents;
data = RCT.data;

triplets = 0;
for j=h-2:-1:l
Vjp1 = V{j+1};
inters = ismember(P{j},Vjp1);
Vjs = L{j}(inters);

dists = data(Vjs,q);

[~,sortInds] = sort(dists,'ascend');

Vj = Vjs(sortInds(1:min(length(sortInds),w)));
triplets = triplets+length(Vjs)*log2(length(Vj));

V{j} = Vj;



end
NN = V{j}(1);
end

