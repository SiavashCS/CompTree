function [ RCT,triplets] = RCTBuildDistM( dists, w ,delta)
%RCT-BUILD Summary of this function goes here
%   Detailed explanation goes here
n = length(dists);
RCT = struct();
RCT.data = dists;
RCT.w = w;
triplets = 0;
% building level sets L

L{1}=1:n;
i=1;
while (length(L{i})>0)
L{i+1} = L{i};
while (isequal(L{i+1} , L{i}))
L{i+1} = [];
for j = L{i}
if rand<(1/delta)
L{i+1} = [L{i+1},j];
end
end
end
i=i+1;

end
RCT.Levels = L;
RCT.height = length(L);
h = length(L);

% insertion loop, P is the same structure as L, keeps the parent item of
% corresponding item in L
P = L;
P{h-1}= L{h-1};
RCT.Parents = P;
for j=h-2:-1:1
Lj = L{j};
counter = 0;
for u=Lj
counter = counter +1;
if ismember(u,L{j+1})
P{j}(counter) = u;
% RCT.Parents = P;
else
[P{j}(counter), trips] = RCTFindNNDistM(RCT,u,j);
triplets = triplets+ trips;
% RCT.Parents = P;
end
end
RCT.Parents = P;


end

RCT.Parents = P;
end



